// JavaScript Document

$(document).ready(function() {
        $("button").mouseover(function() {
       
            $("i").toggleClass("fa-arrow-down");
     
        });
		$("button").mouseleave(function() {
       
            $("i").toggleClass("fa-arrow-down");
     
        });
        
    });

//var sections = document.querySelectorAll('section');
//var navli = document.querySelectorAll('nav ul li');
//
//window.addEventListener('scroll',  () => {
//	let current = '';
//	console.log(pageYOffset);
//	sections.forEach( section =>{
//		const sectionTop = section.offsetTop;
//		console.log(sectionTop);
//		const sectionHeight = section.clientHeight;
//		if(pageYOffset >= sectionTop - sectionHeight/3){
//			current = section.getAttribute('id');
//		}
//		
//	});
//	console.log(current);
//	navli.forEach(li =>{
//		li.classList.remove('active');
//		if(li.classList.contains('current')){
//			li.classList.add('active');
//		}
//	});
//});